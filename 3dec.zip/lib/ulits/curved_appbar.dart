import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import '../Helper/UserController.dart';

class CurvedAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onBack;

  CurvedAppBar({super.key, required this.title, this.onBack});

  final UserController userController = Get.find<UserController>();

  @override
  Size get preferredSize => const Size.fromHeight(80);

  @override
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false, // नीचे के लिए SafeArea ना चाहिए
      child: Container(
        height: 80,
        decoration: const BoxDecoration(
          color: Color(0xFFFF3A20),
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(25),
            bottomRight: Radius.circular(25),
          ),
        ),
        padding: const EdgeInsets.only(top: 5, left: 15, right: 15),
        child: Row(
          children: [
            GestureDetector(
              onTap: onBack ?? () => Navigator.pop(context),
              child: const Icon(
                CupertinoIcons.back,
                color: Colors.white,
                size: 24,
              ),
            ),

            const SizedBox(width: 8),

            Text(
              title,
              style: const TextStyle(
                fontSize: 19,
                color: Colors.white,
                fontWeight: FontWeight.w500,
              ),
            ),

            const Spacer(),

            Obx(
                  () => userController.accountStatus.value
                  ? Row(
                children: [
                  const Icon(
                    Icons.account_balance_wallet_outlined,
                    size: 28,
                    color: Colors.white,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    "₹${userController.walletBalance.value}",
                    style: const TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              )
                  : const SizedBox.shrink(),
            ),
          ],
        ),
      ),
    );
  }

}
