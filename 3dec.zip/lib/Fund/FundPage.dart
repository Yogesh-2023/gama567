import 'package:flutter/material.dart';
import 'package:new_sara/Fund/BankDetailsFragment.dart';

import '../Helper/TranslationHelper.dart';
import '../ulits/curved_appbar.dart';
import 'AddFundScreen.dart';
import 'DepositHistoryPage.dart';
import 'WithdrawScreen.dart';
import 'WithdrawalHistoryPage.dart';

class FundsScreen extends StatelessWidget {
  final void Function(String title)? onItemTap;
  TranslationHelper translationHelper = TranslationHelper();

  FundsScreen({super.key, this.onItemTap});

  final List<_FundOption> fundOptions = [
    _FundOption("Add Funds", Icons.add, Color(0xFFF4D8D0), Colors.orange),
    _FundOption(
      "Manual Deposit Requests",
      Icons.refresh_rounded,
      Color(0xFFF5D6C9),
      Colors.deepOrange,
    ),
    _FundOption(
      "Withdraw History",
      Icons.receipt_long,
      Color(0xFFE7D7F6),
      Colors.deepPurple,
    ),
    _FundOption(
      "Add Bank Details",
      Icons.account_balance,
      Color(0xFFD3F3F4),
      Colors.teal,
    ),
    _FundOption("Withdraw Funds", Icons.money, Color(0xFFDDEAFF), Colors.blue),
    _FundOption(
      "Account Statement",
      Icons.list_alt,
      Color(0xFFE5F8D4),
      Colors.green,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      // Remove SafeArea to utilize full screen space
      appBar: CurvedAppBar(title: 'Funds',),
      body: Padding(
        padding: const EdgeInsets.all(40),
        child: GridView.builder(
          itemCount: fundOptions.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 18,
            crossAxisSpacing: 18,
            childAspectRatio: 0.92,
          ),
          itemBuilder: (context, index) {
            final item = fundOptions[index];
            return GestureDetector(
              onTap: () {
                switch (item.title) {
                  case "Add Funds":
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => AddFundScreen()),
                    );
                    break;
                  case "Manual Deposit Requests":
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => DepositHistoryPage()),
                    );
                    break;
                  case "Withdraw History":
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => WithdrawalHistoryPage(),
                      ),
                    );
                    break;
                  case "Add Bank Details":
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => BankDetailsFragment()),
                    );
                    break;
                  case "Withdraw Funds":
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => WithdrawScreen()),
                    );
                    break;
                  case "Account Statement":
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => DepositHistoryPage()),
                    );
                    break;
                }
              },
              child: Container(
                decoration: BoxDecoration(
                  color: item.bgColor,
                  borderRadius: BorderRadius.circular(26),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const SizedBox(height: 2),
                    // CIRCLE ICON SECTION
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.7),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(item.icon, size: 42, color: item.iconColor),
                    ),
                    // TITLE TEXT
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 0,
                      ),
                      child: Text(
                        item.title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                    // BOTTOM BAR EXACT LIKE SCREENSHOT
                    Container(
                      width: 60,
                      height: 6,
                      decoration: BoxDecoration(
                        color: item.iconColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _FundOption {
  final String title;
  final IconData icon;
  final Color bgColor;
  final Color iconColor;

  _FundOption(this.title, this.icon, this.bgColor, this.iconColor);
}
