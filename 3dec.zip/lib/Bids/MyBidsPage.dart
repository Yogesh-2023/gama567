import 'package:flutter/material.dart';
import 'package:new_sara/Bids/BidHistory/BidHistoryScreen.dart';
import 'package:new_sara/Bids/KingJackpotBidHis/KingJackpotHistoryScreen.dart';
import 'package:new_sara/Bids/KingStartlineBidHis/KingStarlineBidHistoryScreen.dart';

class BidScreen extends StatelessWidget {
  final List<_BidOption> bidOptions = [
    _BidOption(
      "BID HISTORY",
      Icons.groups,
      Colors.purple.shade100,
      Color(0x338011d2), // 20% opacity
    ),

    _BidOption(
      "KING STARLINE BID HISTORY",
      Icons.account_balance,
      Colors.lightBlue.shade100,
      Color(0xff0A52CB),
    ),
    _BidOption(
      "KING JACKPOT BID HISTORY",
      Icons.style,
      Colors.teal.shade100,
      Colors.teal,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.only(top: 30),
        child: GridView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
          itemCount: bidOptions.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 18,
            mainAxisSpacing: 18,
            childAspectRatio: 0.95,
          ),
          itemBuilder: (context, index) {
            final item = bidOptions[index];

            return GestureDetector(
              onTap: () {
                if (item.title == "BID HISTORY") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => BidHistoryPage()),
                  );
                } else if (item.title == "KING STARLINE BID HISTORY") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => KingStarlineBidHistoryScreen(),
                    ),
                  );
                } else if (item.title == "KING JACKPOT BID HISTORY") {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => KingJackpotHistoryScreen(),
                    ),
                  );
                }
              },

              child: Container(
                decoration: BoxDecoration(
                  color: item.bgColor,
                  borderRadius: BorderRadius.circular(26),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // TOP ICON CIRCLE (same as your screenshot)
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.65),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(item.icon, size: 42, color: item.iconColor),
                    ),

                    const SizedBox(height: 18),

                    // TITLE
                    Text(
                      item.title,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),

                    const SizedBox(height: 14),

                    // BOTTOM COLORED INDICATOR
                    Container(
                      width: 55,
                      height: 6,
                      decoration: BoxDecoration(
                        color: item.iconColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _BidOption {
  final String title;
  final IconData icon;
  final Color bgColor;
  final Color iconColor;

  _BidOption(this.title, this.icon, this.bgColor, this.iconColor);
}
