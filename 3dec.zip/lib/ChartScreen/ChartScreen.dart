import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:new_sara/ChartScreen/ChartTableScreen.dart';
import 'package:new_sara/ulits/Constents.dart';

class Game {
  final int gameId;
  final String gameName;
  final String gameType;

  Game({required this.gameId, required this.gameName, required this.gameType});

  factory Game.fromJson(Map<String, dynamic> json) {
    return Game(
      gameId: json['gameId'],
      gameName: json['gameName'],
      gameType: json['gameType'],
    );
  }
}

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key});

  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  List<Game> allGames = [];
  List<Game> filteredGames = [];
  final TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchGames();
  }

  Future<void> fetchGames() async {
    final url = '${Constant.apiEndpoint}chart-game-list';
    final String accessToken = GetStorage().read('accessToken');
    final String deviceId = GetStorage().read('deviceId');
    final String deviceName = GetStorage().read('deviceName');

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'deviceId': deviceId,
          'deviceName': deviceName,
          'accessStatus': '1',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List gamesJson = jsonData['info'];

        final games = gamesJson.map((e) => Game.fromJson(e)).toList();

        setState(() {
          allGames = List<Game>.from(games);
          filteredGames = allGames;
        });
      }
    } catch (e) {
      print("Exception: $e");
    }
  }

  void filterSearch(String query) {
    final filtered = allGames
        .where((g) => g.gameName.toLowerCase().contains(query.toLowerCase()))
        .toList();

    setState(() {
      filteredGames = filtered;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      // ---------------- APP BAR ----------------
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          "Charts",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
      ),

      body: Column(
        children: [
          // ---------------- SEARCH BAR ----------------
          Padding(
            padding: const EdgeInsets.all(12),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.black, width: 2.5),
              ),
              child: TextField(
                controller: searchController,
                onChanged: filterSearch,
                decoration: InputDecoration(
                  hintText: "Search chart",
                  hintStyle: TextStyle(color: Colors.grey.shade600),
                  prefixIcon: const Icon(Icons.search, size: 28),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 8,
                  ),
                ),
              ),
            ),
          ),

          // ---------------- GRID LIST ----------------
          Expanded(
            child: filteredGames.isEmpty
                ? const Center(
                    child: CircularProgressIndicator(color: Color(0xffF95C33)),
                  )
                : GridView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: filteredGames.length,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 16,
                          crossAxisSpacing: 16,
                          childAspectRatio: 2.8,
                        ),
                    itemBuilder: (context, index) {
                      final game = filteredGames[index];

                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ChartTableScreen(
                                gameId: game.gameId,
                                gameType: game.gameType,
                              ),
                            ),
                          );
                        },

                        // ---- CARD DESIGN (LIKE HOMEPAGE UI) ----
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xffF95c33),
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.12),
                                blurRadius: 5,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              game.gameName,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 16,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
